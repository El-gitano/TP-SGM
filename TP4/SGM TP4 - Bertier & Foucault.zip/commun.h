#ifndef COMMUN_H

#define COMMUN_H

#define NBPAGES 50

#endif
